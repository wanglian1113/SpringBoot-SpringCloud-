# 整合SpringBoot Mysql Mybatis CXF/JSR-RS

# 1、mysql中新建demo库运行resources下sql文件
# 2、修改application.properties修改数据源
# 3、启动主类
