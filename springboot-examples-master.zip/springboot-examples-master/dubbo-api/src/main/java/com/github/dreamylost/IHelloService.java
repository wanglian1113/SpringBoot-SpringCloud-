package com.github.dreamylost;

public interface IHelloService {

    String sayHello(String name);

}
